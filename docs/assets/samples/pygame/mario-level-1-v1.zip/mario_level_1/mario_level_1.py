#!/usr/bin/env python3
# PythonIDE Pygame 示例：完整关卡项目
#
# 这是一个较完整的 pygame 项目结构示例，包含 data 包、状态机、角色、
# 地图、图片、字体、音乐和音效。运行本文件即可启动入口。
#
# 原项目作者: justinarmstrong
# 用途: 非商业学习与 pygame 项目结构参考。

__author__ = "justinarmstrong"

import os
import sys
import pygame as pg
from data.main import main


if __name__ == "__main__":
    # 让资源路径始终以本文件所在目录为准，避免从 IDE 其他目录运行时找不到 resources。
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    main()
    pg.quit()
    sys.exit()

# PythonIDE Pygame 示例：完整关卡项目

这是一个完整度较高的 Pygame 项目示例。它不是单文件脚本，而是展示真实项目通常会拆分出的结构：

- `mario_level_1.py`：运行入口
- `data/main.py`：状态机入口
- `data/states/`：菜单、加载、关卡等状态
- `data/components/`：角色、敌人、金币、砖块、旗杆等组件
- `resources/graphics/`：图片素材
- `resources/music/` 和 `resources/sound/`：音乐与音效
- `resources/fonts/`：字体

## 运行方式

打开 `mario_level_1.py`，点击运行。

## 控制方式

- 方向键：移动
- `a`：跳跃
- `s`：加速 / 动作

## 说明

这个项目来自公开学习示例，原作者为 `justinarmstrong`。它适合用来学习 Pygame 项目拆分、资源加载、状态机、碰撞检测和 2D 横版关卡结构。

如果你准备把应用发布到商店，建议把这类带知名游戏角色风格的素材替换成你自己的原创资源。
